package com.voidx.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class VoidXScreen extends Screen {
    private static final int PURPLE = 0xFF9B4DFF;
    private static final int PURPLE_DARK = 0xFF32164E;
    private static final int PANEL = 0xEE0C0A12;
    private static final int PANEL_2 = 0xEE120E1A;
    private static final int LINE = 0xFF2C2237;
    private static final int TEXT = 0xFFF5F1FA;
    private static final int MUTED = 0xFF8C8297;

    public VoidXScreen() {
        super(Component.literal("VoidX Client"));
    }

    private String nickname() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) return mc.player.getGameProfile().name();
        return mc.getUser().getName();
    }

    @Override
    protected void init() {
        int sidebar = 190;
        int left = sidebar + 20;
        int top = 92;

        addRenderableWidget(menuButton("Inicio", left, top, 125, 30, true));
        addRenderableWidget(menuButton("Mods", left, top + 38, 125, 30, false));
        addRenderableWidget(menuButton("Visuales", left, top + 76, 125, 30, false));
        addRenderableWidget(menuButton("HUD", left, top + 114, 125, 30, false));
        addRenderableWidget(menuButton("Rendimiento", left, top + 152, 125, 30, false));
        addRenderableWidget(menuButton("Config", left, top + 190, 125, 30, false));
        addRenderableWidget(menuButton("Keybinds", left, top + 228, 125, 30, false));
        addRenderableWidget(menuButton("Perfil", left, top + 266, 125, 30, false));
    }

    private Button menuButton(String label, int x, int y, int w, int h, boolean active) {
        return Button.builder(Component.literal(label), b -> {})
                .bounds(x, y, w, h)
                .build();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g, mouseX, mouseY, partialTick);

        int w = this.width;
        int h = this.height;
        int sidebarW = 190;

        // Base
        g.fill(0, 0, w, h, 0xFF07060B);
        g.fill(0, 0, sidebarW, h, 0xFF09080E);
        g.fill(sidebarW, 0, sidebarW + 1, h, LINE);

        // Purple ambient blocks / decoration
        g.fill(w - 310, 0, w, 2, PURPLE);
        g.fill(sidebarW + 22, 64, w - 25, 65, PURPLE_DARK);
        g.fill(sidebarW + 22, h - 24, w - 25, h - 23, PURPLE_DARK);

        // Brand
        g.fill(25, 23, 61, 59, 0xFF261039);
        g.fill(29, 27, 57, 55, PURPLE_DARK);
        g.drawCenteredString(this.font, "V", 43, 34, 0xFFFFFFFF);
        g.drawString(this.font, "VoidX", 72, 26, TEXT);
        g.drawString(this.font, "CLIENT", 72, 41, PURPLE);
        g.drawString(this.font, "v0.1.0", 126, 42, 0xFF5D5368);

        // Welcome header
        g.drawString(this.font, "Bienvenido, " + nickname(), sidebarW + 22, 27, TEXT);
        g.drawString(this.font, "Tu experiencia empieza aquí.", sidebarW + 22, 45, MUTED);

        // Main hero
        int heroX = sidebarW + 22;
        int heroY = 82;
        int heroW = w - sidebarW - 355;
        int heroH = 230;
        panel(g, heroX, heroY, heroW, heroH);
        g.drawString(this.font, "VOIDX", heroX + 25, heroY + 38, 0xFFFFFFFF);
        g.drawString(this.font, "CLIENT", heroX + 27, heroY + 58, PURPLE);
        g.drawString(this.font, "Más que un cliente,", heroX + 25, heroY + 105, TEXT);
        g.drawString(this.font, "una experiencia.", heroX + 25, heroY + 123, PURPLE);
        g.fill(heroX + 25, heroY + 145, heroX + 120, heroY + 148, PURPLE);

        // Decorative fake voxel figure area; real player renderer comes next.
        int px = heroX + heroW - 125;
        int py = heroY + 38;
        g.fill(px + 30, py, px + 78, py + 48, 0xFF242027);
        g.fill(px + 24, py + 44, px + 84, py + 112, 0xFF7131B4);
        g.fill(px + 5, py + 47, px + 24, py + 108, 0xFF512384);
        g.fill(px + 84, py + 47, px + 103, py + 108, 0xFF512384);
        g.fill(px + 28, py + 109, px + 54, py + 171, 0xFF28212E);
        g.fill(px + 54, py + 109, px + 80, py + 171, 0xFF3A3041);
        g.drawCenteredString(this.font, nickname(), px + 54, py - 14, TEXT);

        // Right profile / cosmetics panel
        int sideX = w - 315;
        int sideY = 82;
        int sideW = 290;
        int sideH = 230;
        panel(g, sideX, sideY, sideW, sideH);
        g.drawString(this.font, "TU PERSONAJE", sideX + 18, sideY + 18, MUTED);
        g.drawString(this.font, nickname(), sideX + 18, sideY + 36, TEXT);
        g.drawString(this.font, "COSMÉTICOS", sideX + 18, sideY + 70, PURPLE);
        cosmetic(g, sideX + 18, sideY + 88, "Capa");
        cosmetic(g, sideX + 18, sideY + 126, "Sombrero");
        cosmetic(g, sideX + 18, sideY + 164, "Efecto");

        // Bottom cards
        int cardY = h - 135;
        int gap = 10;
        int cardW = (w - sidebarW - 44 - gap * 3) / 4;
        card(g, sidebarW + 22, cardY, cardW, 86, "Rendimiento", "Mejora FPS y reduce lag.");
        card(g, sidebarW + 22 + cardW + gap, cardY, cardW, 86, "Visuales", "Controla tu entorno.");
        card(g, sidebarW + 22 + (cardW + gap) * 2, cardY, cardW, 86, "HUD", "Personaliza tu interfaz.");
        card(g, sidebarW + 22 + (cardW + gap) * 3, cardY, cardW, 86, "Configuración", "Ajusta todo a tu gusto.");

        super.render(g, mouseX, mouseY, partialTick);
    }

    private void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, PANEL);
        g.fill(x, y, x + w, y + 1, LINE);
        g.fill(x, y + h - 1, x + w, y + h, LINE);
        g.fill(x, y, x + 1, y + h, LINE);
        g.fill(x + w - 1, y, x + w, y + h, LINE);
        g.fill(x + 10, y + 10, x + 12, y + 12, PURPLE);
    }

    private void card(GuiGraphics g, int x, int y, int w, int h, String title, String desc) {
        panel(g, x, y, w, h);
        g.drawString(this.font, title, x + 14, y + 18, TEXT);
        g.drawString(this.font, desc, x + 14, y + 37, MUTED);
        g.drawString(this.font, ">", x + w - 22, y + 18, PURPLE);
    }

    private void cosmetic(GuiGraphics g, int x, int y, String name) {
        g.fill(x, y, x + 28, y + 28, 0xFF191320);
        g.fill(x, y, x + 28, y + 1, PURPLE_DARK);
        g.drawString(this.font, name, x + 38, y + 9, TEXT);
        g.drawString(this.font, "ACTIVO", x + 38, y + 18, 0xFF76588E);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
